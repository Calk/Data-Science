#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "Person.h"

#define BUF_SIZE 100

Person *CreatePerson(char *name, size_t age)
{
	Person *p = malloc(sizeof(Person));

	if (p)
	{
		p->name = malloc((name ? strlen(name) : 0) + 1);
		if (p->name)
		{
			strcpy(p->name, name ? name : "");
			p->age = age;
		}
		else
		{
			/* handle out of memory error. */
			free(p);
			p = NULL;
		}
	}

	return p;
}

void FreePerson(Person *p)
{
	if (p)
	{
		free(p->name);
		free(p);
	}
}

Person *AddPerson()
{
	char buffer[BUF_SIZE];
	size_t age;

	printf("Please enter a person's name: ");
	scanf_s("%s", buffer, BUF_SIZE);

	printf("Please enter %s's age: ", buffer);
	scanf("%d", &age);

	return CreatePerson(buffer, age);
}
