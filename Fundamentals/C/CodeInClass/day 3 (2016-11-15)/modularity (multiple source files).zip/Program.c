#include "Person.h"
#include <malloc.h>

/* Promises, promises... */
void NoTaxRaise();
int FullEmployment(double, int, int);

struct Parent;

struct Child
{
	struct Parent *p;
};

struct Parent
{
	struct Child *c;
};

Person *people[10] = { 0 };

void AddPeople()
{
	people[0] = AddPerson();
	people[1] = AddPerson();
	people[3] = AddPerson();
}

void main(void)
{
	AddPeople();

	Person *p2 = people[2];
	
	/* Deallocate whole DB - problematic */
	for (size_t index = 0; index < 10; ++index)
	{
		FreePerson(people[index]);
	}

	/* Deallocate single object - problematic */
	free(p2);
}